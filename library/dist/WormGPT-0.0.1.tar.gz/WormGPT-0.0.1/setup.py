import setuptools

setuptools.setup(
    name='WormGPT',
    version='0.0.1',
    author='MohamedSarhan , BlackCrow',
    description='WormGPT API Using: api_key = "Your_api_from_openai"\napi_openai(api_key)\nWormgpt(api_key)\nlogin("Your_Token", "pass_Token")\ncontent Us For Git token and pass My Account https://t.me/Black80Crow',
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    url='https://mohamed-sarhan.netlify.app/',
)
